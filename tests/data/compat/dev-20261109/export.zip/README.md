# litresearch export

Format `litresearch-export`, version 1, written by litresearch 0.2.0-dev. All text is UTF-8; dates and times are ISO 8601 (local time); JSON files are described by the JSON Schemas in `schemas/`. `manifest.json` lists the SHA-256 checksum of every file.

Import with `litresearch import-all FILE.zip` (a new profile) or `litresearch import-all FILE.zip --into PROFILE` (merge). Everything is checked before anything is changed.

## Files

- `papers.json`: Every paper any other file refers to. `key` ("p<id>") is how the other files refer to it; identifiers (doi, pmid, pmcid, arxiv_id, s2_id, openalex_id, bibtex_key) and metadata (title, authors, year, pub_date, venue, abstract, metrics such as citation_count, fwci, citation_percentile, topics); `in_library`, `folders` and `tags` follow the libraries.
- `libraries.json`: Your libraries: name, description, kind (imported, recommended), format of the last import, use_for_recommendations, and `papers`: every member with its `paper` key, `citation_key`, `folders`, `tags` and `added_at`. `files` names the library's BibTeX and CSL-JSON copy.
- `libraries/`: Each library as BibTeX (`.bib`) and CSL-JSON (`.json`) for reference managers. Views of libraries.json: not read on import, but checked against it.
- `readings.json`: Per paper: current `status` (abstract, skimmed, read, thorough, dismissed), `rating` (1-5), `notes` (the note body) and `updated_at`.
- `status_events.json`: The reading log: every status change with `at` and `was_queue_top` (it was the top of the queue).
- `xp_ledger.json`: Every XP transaction in time order: `points`, `kind`, `reason`, `at`, the `paper` if any and the running `balance`; `total` is the sum.
- `badges.json`: Unlocked badges: `code`, `name`, `unlocked_at`.
- `queue.json`: The reading queue: `position` (1 = read next), `source` and `added_at`.
- `recommendations.json`: Recommendation batches: `week_start`, `created_at`, `n_candidates`, `warnings`, `funnel` (candidates removed per step), `params` (settings used) and `items` (paper, rank, category, score, `breakdown` with the evidence, reason).
- `example_choices.json`: Papers you added to (`include`) or removed from (`exclude`) the positive or negative example list for Semantic Scholar.
- `profile.json`: The profile: `name`, `created_at`, the locked game `rules`, their `fingerprint`, the `app_version` that created it; `xp_total`.
- `settings.yaml`: The profile's settings (topics, excluded terms, selection, sources, queue, library, paths); paths are not taken over on import.
- `reading_log.tsv`: The reading log as a table for spreadsheets (as Reading → Read papers exports it). Not read on import.
- `xp_ledger.tsv`: The XP ledger as a table for spreadsheets. Not read on import.
- `notes/`: The note files as they are (Markdown with YAML front matter, format litresearch-note/1; `litresearch_id: N` is paper key pN).
- `schemas/`: JSON Schema (draft 2020-12) of every JSON file.

Not included (recomputed or machine-specific): embeddings, the example lists themselves, the import log, the sync state of note files, file paths.
