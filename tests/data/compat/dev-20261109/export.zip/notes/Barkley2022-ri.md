---
litresearch_id: 1
title: Cancer cell states recur across tumor types and form specific interactions with the tumor microenvironment
authors:
  - Barkley, Dalia
  - Moncada, Reuben
  - França, Gustavo S
  - Yanai, Itai
year: 2022
journal: Nature Genetics
doi: 10.1038/s41588-022-01141-9
pmid: '35931863'
citekey: Barkley2022-ri
status: thorough
rating: 5
tags: []
updated: '2026-11-09T14:43:16'
format: litresearch-note/1
---

[2026-09-08T12:00:00] Reflection on the study design and what it means for my own work. Reflection on the study design and what it means for my own work. Reflection on the study design and what it means for my own work.
