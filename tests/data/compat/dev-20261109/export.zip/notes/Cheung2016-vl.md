---
litresearch_id: 2
title: 'A collective route to metastasis: Seeding by tumor cell clusters'
authors:
  - Cheung, Kevin J
  - Ewald, Andrew J
year: 2016
journal: Science
doi: 10.1126/science.aaf6546
pmid:
citekey: Cheung2016-vl
status: read
rating: 4
tags:
  - metastasis
  - circulating-tumor-cells
updated: '2026-11-09T14:43:16'
format: litresearch-note/1
---

[2026-09-15T12:00:00] Short note.
